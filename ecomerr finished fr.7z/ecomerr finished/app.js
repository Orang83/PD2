const express = require("express");
const path = require("path");
const mysql = require("mysql");
const session = require('express-session');  // Import the session module here
const dotenv = require("dotenv");
const hbs = require("hbs");
const cartRoutes = require('./routes/cart');
const { engine } = require('express-handlebars');



dotenv.config({ path: './.env' });

const app = express();

// MySQL connection setup
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));
// Set up public directory for static files (like images, CSS, JS)
const publicDirectory = path.join(__dirname, './public');
app.use(express.static(publicDirectory));

// Middleware to parse incoming request bodies
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use('/cart', cartRoutes);
// Set up Handlebars as view engine
app.set('view engine', 'hbs');

// Set up session middleware to store the cart in the session
app.use(session({
    secret: 'secret', // Secret key for session encryption
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set 'secure: true' in production with HTTPS
}));

// Check MySQL connection
db.connect((error) => {
    if (error) {
        console.error("Error connecting to MySQL:", error);
        process.exit(1); // Exit the process if MySQL connection fails
    } else {
        console.log("MYSQL Connected...");
    }
});

// Define routes for your app
app.use('/', require('./routes/pages')); // Pages route (e.g., Home, Cart view)
app.use('/auth', require('./routes/auth')); // Auth route (e.g., Login, Register)
app.use('/products', require('./routes/products')); // Add route for products (the products controller)
app.use('/cart', require('./routes/cart')); // Add route for cart (the cart controller)


// Example POST request for handling contact form submissions
app.post('/contacts', async (req, res) => {
    const { name, email, text } = req.body;

    if (!name || !email || !text) {
        return res.status(400).send('All fields are required!');
    }

    try {
        const query = 'INSERT INTO contactss (name, email, text) VALUES (?, ?, ?)';
        db.query(query, [name, email, text], (err, result) => {
            if (err) {
                console.error('Error inserting data:', err);
                return res.status(500).send('Error saving contact.');
            }

            res.send('Contact saved successfully!');
            console.log('Data inserted:', result);
        });
    } catch (err) {
        console.error('Error inserting data:', err);
        res.status(500).send('Error saving contact.');
    }
});


// Endpoint to add item to cart
// Endpoint to add item to cart
app.post('/add-to-cart', (req, res) => {
    const { productName, price, quantity } = req.body;
    const findSql = 'SELECT * FROM cart WHERE product_name = ?';
    const updateSql = 'UPDATE cart SET quantity = quantity + ? WHERE product_name = ?';
    const insertSql = 'INSERT INTO cart (product_name, price, quantity) VALUES (?, ?, ?)';

    db.query(findSql, [productName], (err, results) => {
        if (err) throw err;
        if (results.length > 0) {
            db.query(updateSql, [quantity, productName], (err, result) => {
                if (err) throw err;
                res.json({ message: 'Item quantity updated in cart' });
            });
        } else {
            db.query(insertSql, [productName, price, quantity], (err, result) => {
                if (err) throw err;
                res.json({ message: 'Item added to cart' });
            });
        }
    });
});


// Endpoint to retrieve cart items
app.get('/cart-items', (req, res) => {
    const sql = 'SELECT * FROM cart';
    db.query(sql, (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.delete('/clear-cart', (req, res) => {
    const sql = 'DELETE FROM cart';
    db.query(sql, (err, result) => {
        if (err) throw err;
        res.json({ success: true });
    });
});




// Start the server
app.listen(5000, () => {
    console.log("Server started on port 5000");
});

