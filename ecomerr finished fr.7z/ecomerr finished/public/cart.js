document.addEventListener("DOMContentLoaded", function() {
    const cartItemsContainer = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    const buyButton = document.getElementById('buy-button');
    const clearButton = document.getElementById('clear-button');
    const totalContainer = cartTotal.closest('p');

    fetch('/cart-items')
        .then(response => response.json())
        .then(cartItems => {
            let total = 0;

            if (cartItems.length === 0) {
                
                const emptyMessage = document.createElement('tr');
                emptyMessage.innerHTML = '<td colspan="5">Krepšelis tuščias :(</td>';
                cartItemsContainer.appendChild(emptyMessage);
                
                buyButton.style.display = 'none';
                clearButton.style.display = 'none';
                totalContainer.style.display = 'none';
            } else {
                // Display cart items and calculate total price
                cartItems.forEach((item, index) => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.product_name}</td>
                        <td>${item.quantity}</td>
                        <td>$${item.price.toFixed(2)}</td>
                        <td>$${(item.price * item.quantity).toFixed(2)}</td>
                        
                    `;
                    cartItemsContainer.appendChild(row);
                    total += item.price * item.quantity;
                });
                cartTotal.textContent = total.toFixed(2);
            }
        })
        .catch(error => console.error('Error fetching cart items:', error));

    buyButton.addEventListener('click', () => {
        fetch('/clear-cart', {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Purchase successful!');
                location.reload();
            }
        })
        .catch(error => console.error('Error clearing cart:', error));
    });
});

function removeFromCart(itemId) {
    fetch(`/remove-from-cart/${itemId}`, {
        method: 'DELETE',
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload(); 
        } else {
            console.error(data.message);
        }
    })
    .catch(error => console.error('Error removing item from cart:', error));
}
