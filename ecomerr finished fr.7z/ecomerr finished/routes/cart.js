// routes/cart.js
const express = require('express');
const router = express.Router();

// Import the controller from controllers folder
const { addToCart } = require('../controllers/cart');  // Ensure the correct path

// POST route to add product to cart
router.post('/add-to-cart', addToCart);  // This will call addToCart function when /add-to-cart is hit

module.exports = router;
