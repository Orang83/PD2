// controllers/cart.js
exports.addToCart = (req, res) => {
    const { pid, quantity } = req.body;

    // Validate if pid and quantity are provided
    if (!pid || !quantity) {
        return res.status(400).send('Product ID and quantity are required.');
    }

    // For now, we just log the added product to the console
    console.log(`Product ID: ${pid} Quantity: ${quantity}`);

    // Send success response
    res.status(200).send('Product added to cart');
};
