const mysql = require("mysql");
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const validator = require('validator');

// MySQL connection setup
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

const getProducts = (req, res) => {
    const query = 'SELECT * FROM products'; // Adjust the query as per your table schema
    db.query(query, (err, results) => {
        if (err) {
            console.error("Error fetching products:", err);
            return res.status(500).send("Error fetching products");
        }
        res.render('products', { products: results });  // Pass products data to the template
    });
};

module.exports = { getProducts };
// Get all products

// Add product to the cart
exports.addToCart = (req, res) => {
    const { pid, qnt } = req.body;
    
    if (!pid || !qnt) {
        return res.status(400).send("Product ID and quantity are required.");
    }

    // Check if the product exists
    const query = 'SELECT * FROM products WHERE pid = ?';  // Use 'pid' for the query if that's your column name
    db.query(query, [pid], (err, results) => {
        if (err) {
            console.error("Error checking product:", err);
            return res.status(500).send("Error checking product");
        }

        if (results.length === 0) {
            return res.status(404).send("Product not found.");
        }

        const product = results[0];
        const cartItem = {
            pid: product.pid,         // Use 'pid' as per your database column
            pname: product.pname,     // Use 'pname' for product name
            price: product.price,     // Use 'price' for the product price
            qnt: qnt,                 // Use 'qnt' for quantity
            pdescription: product.pdescription, // Use 'pdescription' for description
            imgurl: product.imgurl    // Use 'imgurl' for the image URL
        };

        // Store the cart data in the session (or localStorage on the frontend)
        if (!req.session.cart) {
            req.session.cart = [];
        }

        // Check if the product is already in the cart
        const existingProduct = req.session.cart.find(item => item.pid === product.pid);
        if (existingProduct) {
            // If the product is already in the cart, update the quantity
            existingProduct.qnt += qnt;
        } else {
            // Otherwise, add the product to the cart
            req.session.cart.push(cartItem);
        }

        // Respond with the updated cart
        res.json(req.session.cart);
    });
};

// View Cart
exports.viewCart = (req, res) => {
    res.json(req.session.cart || []); // Return cart items, or an empty array if no items
};
